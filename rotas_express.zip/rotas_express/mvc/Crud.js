import connection from "./properties";

class Crud {

    //Insert - Inserir dados
    save(car, callback){
        let sql = "insert into cars set ?"
        connection.query(sql, car, function(error, results,fields){
        if(error) throw error
        car.id = results.insertId
        
        callback(results)
        })
        connection.end()
    }
}

export default Crud