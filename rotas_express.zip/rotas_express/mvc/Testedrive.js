import Crud from "./Crud";

//Crud.prototype.save - gambiarra

function salvar(){

const crud = new Crud()

let car = {"carsname":"impala", "color":"red", "age": 1977}

crud.save(car, function(car){
    console.log("Salvo no Banco de Dados!")

})

}
salvar()