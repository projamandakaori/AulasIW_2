create DATABASE auto;
 use auto;
 
 
 create table cars(
    id int AUTO_INCREMENT not null,
    carsname VARCHAR(50) null,
    color VARCHAR(50) null,
    age INT NULL,
    PRIMARY KEY(id)
 );

 select * from cars;